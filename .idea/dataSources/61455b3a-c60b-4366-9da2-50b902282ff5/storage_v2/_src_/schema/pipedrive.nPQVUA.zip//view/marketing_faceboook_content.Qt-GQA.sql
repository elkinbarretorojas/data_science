create definer = pipedrive@`%` view marketing_faceboook_content as
select distinct `pipedrive`.`marketing_facebook`.`Adset_Name` AS `Adset_Name`
from `pipedrive`.`marketing_facebook`;

