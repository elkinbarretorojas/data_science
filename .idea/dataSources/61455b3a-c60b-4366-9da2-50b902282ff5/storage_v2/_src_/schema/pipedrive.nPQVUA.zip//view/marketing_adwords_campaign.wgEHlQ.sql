create definer = pipedrive@`%` view marketing_adwords_campaign as
select distinct `pipedrive`.`marketing_adwords`.`Campaign_metabase` AS `Campaign_metabase`
from `pipedrive`.`marketing_adwords`;

