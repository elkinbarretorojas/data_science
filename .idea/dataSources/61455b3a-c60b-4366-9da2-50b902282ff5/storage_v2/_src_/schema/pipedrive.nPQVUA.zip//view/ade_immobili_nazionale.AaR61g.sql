create definer = pipedrive@`%` view ade_immobili_nazionale as
select `a`.`id`                     AS `id`,
       `a`.`codice_immobile_visura` AS `codice_immobile_visura`,
       `a`.`fogliotipo`             AS `fogliotipo`,
       `a`.`partnum`                AS `partnum`,
       `a`.`subanno`                AS `subanno`,
       `a`.`indirizzo`              AS `indirizzo`,
       `a`.`classamento`            AS `classamento`,
       `a`.`classe`                 AS `classe`,
       `a`.`consistenza`            AS `consistenza`,
       `a`.`rendita`                AS `rendita`,
       `a`.`partita`                AS `partita`,
       `a`.`categoria`              AS `categoria`,
       `a`.`provincia`              AS `provincia`,
       `a`.`created_at`             AS `created_at`,
       `a`.`updated_at`             AS `updated_at`
from `ade_production`.`immobili_nazionale` `a`;

