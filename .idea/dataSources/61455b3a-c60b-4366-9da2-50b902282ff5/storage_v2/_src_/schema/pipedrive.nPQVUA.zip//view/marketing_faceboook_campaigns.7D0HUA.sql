create definer = pipedrive@`%` view marketing_faceboook_campaigns as
select distinct `pipedrive`.`marketing_facebook`.`Campaign_Name` AS `Campaign_Name`
from `pipedrive`.`marketing_facebook`;

