create definer = pipedrive@`%` view leads_deals_person as
select `leads`.`person_id`                   AS `person_id`,
       `leads`.`mkt_acquisition_channel`     AS `mkt_acquisition_channel`,
       `leads`.`property_id`                 AS `property_id`,
       `leads`.`mkt_acquisition_content`     AS `mkt_acquisition_content`,
       `leads`.`mkt_acquisition_campaign`    AS `mkt_acquisition_campaign`,
       `leads`.`codfisc`                     AS `Codice_Fiscale`,
       `pipedrive`.`person`.`add_time`       AS `person_add_time`,
       `leads`.`is_archived`                 AS `is_archived`,
       ''                                    AS `deal_id`,
       'deal'                                AS `status`,
       `pipedrive`.`person`.`phone`          AS `phone`,
       `leads`.`city`                        AS `city`,
       0                                     AS `pipeline_id`,
       1                                     AS `is_lead`,
       `leads`.`lead_id`                     AS `lead_id`,
       `leads`.`title`                       AS `title`,
       `leads`.`Qualified_Ready_nel_passato` AS `Qualified_Ready_nel_passato`,
       ''                                    AS `owner_name`,
       `leads`.`creator_id`                  AS `creator_user_id`,
       `leads`.`owner_id`                    AS `pre_sales`
from (`pipedrive`.`leads_api` `leads` left join `pipedrive`.`person`
      on ((`leads`.`person_id` = `pipedrive`.`person`.`id`)))
union
select `deals`.`person_id`                   AS `person_id`,
       `deals`.`mkt_acquisition_channel`     AS `mkt_acquisition_channel`,
       `deals`.`property_id`                 AS `property_id`,
       `deals`.`mkt_acquisition_content`     AS `mkt_acquisition_content`,
       `deals`.`mkt_acquisition_campaigns`   AS `mkt_acquisition_campaign`,
       `deals`.`codfisc`                     AS `Codice_Fiscale`,
       `person`.`add_time`                   AS `person_add_time`,
       2                                     AS `is_archived`,
       `deals`.`deal_id`                     AS `deal_id`,
       `deals`.`status`                      AS `status`,
       `person`.`phone`                      AS `phone`,
       `deals`.`city`                        AS `city`,
       `deals`.`pipeline_id`                 AS `pipeline_id`,
       0                                     AS `is_lead`,
       ''                                    AS `lead_id`,
       `deals`.`title`                       AS `title`,
       `deals`.`Qualified_Ready_nel_passato` AS `Qualified_Ready_nel_passato`,
       `deals`.`owner_name`                  AS `owner_name`,
       `deals`.`creator_user_id_id`          AS `creator_user_id_id`,
       `deals`.`creator_user_id_id`          AS `pre_sales`
from (`pipedrive`.`deals_api` `deals` left join `pipedrive`.`persons_api` `person`
      on ((`deals`.`person_id_value` = `person`.`id`)));

