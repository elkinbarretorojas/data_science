create definer = pipedrive@`%` view ade_citta as
select `a`.`id`         AS `id`,
       `a`.`comune_cat` AS `comune_cat`,
       `a`.`territorio` AS `territorio`,
       `a`.`nome`       AS `nome`,
       `a`.`priorita`   AS `priorita`
from `ade_production`.`citta` `a`;

