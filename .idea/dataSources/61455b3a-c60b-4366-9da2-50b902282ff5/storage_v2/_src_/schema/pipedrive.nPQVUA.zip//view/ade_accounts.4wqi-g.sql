create definer = pipedrive@`%` view ade_accounts as
select `ade_production`.`accounts`.`username`         AS `username`,
       `ade_production`.`accounts`.`password`         AS `password`,
       `ade_production`.`accounts`.`in_use`           AS `in_use`,
       `ade_production`.`accounts`.`last_activity`    AS `last_activity`,
       `ade_production`.`accounts`.`password_expired` AS `password_expired`,
       `ade_production`.`accounts`.`available`        AS `available`
from `ade_production`.`accounts`;

