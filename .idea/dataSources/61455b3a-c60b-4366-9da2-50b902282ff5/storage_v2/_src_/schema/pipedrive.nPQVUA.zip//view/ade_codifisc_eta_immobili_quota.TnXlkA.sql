create definer = pipedrive@`%` view ade_codifisc_eta_immobili_quota as
select `a`.`id`          AS `id`,
       `a`.`codfisc`     AS `codfisc`,
       `a`.`eta`         AS `eta`,
       `a`.`id_immobile` AS `id_immobile`,
       `a`.`id_citta`    AS `id_citta`,
       `a`.`quota`       AS `quota`
from `ade_production`.`codifisc_eta_immobili_quota` `a`;

