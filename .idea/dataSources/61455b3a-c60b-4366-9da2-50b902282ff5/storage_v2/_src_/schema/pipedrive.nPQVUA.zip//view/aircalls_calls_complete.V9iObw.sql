create definer = pipedrive@`%` view aircalls_calls_complete as
select `pipedrive`.`aircalls_calls`.`id`                       AS `id`,
       `pipedrive`.`aircalls_calls`.`direction`                AS `direction`,
       `pipedrive`.`aircalls_calls`.`status`                   AS `status`,
       `pipedrive`.`aircalls_calls`.`missed_call_reason`       AS `missed_call_reason`,
       cast(`pipedrive`.`aircalls_calls`.`started_at` as date) AS `started_at`,
       cast(`pipedrive`.`aircalls_calls`.`ended_at` as date)   AS `ended_at`,
       `pipedrive`.`aircalls_calls`.`duration`                 AS `duration`,
       `pipedrive`.`aircalls_calls`.`raw_digits`               AS `raw_digits`,
       `pipedrive`.`aircalls_calls`.`user_id`                  AS `user_id`
from `pipedrive`.`aircalls_calls`
union
select `pipedrive`.`aircall_calls_historical`.`Call ID`                         AS `Call ID`,
       `pipedrive`.`aircall_calls_historical`.`Direction`                       AS `Direction`,
       `pipedrive`.`aircall_calls_historical`.`Call Status`                     AS `Call Status`,
       `pipedrive`.`aircall_calls_historical`.`Missed Reason`                   AS `Missed Reason`,
       cast(`pipedrive`.`aircall_calls_historical`.`Call Created Date` as date) AS `started_at`,
       cast(`pipedrive`.`aircall_calls_historical`.`Ended Time` as date)        AS `ended_at`,
       `pipedrive`.`aircall_calls_historical`.`In Call Duration`                AS `In Call Duration`,
       `pipedrive`.`aircall_calls_historical`.`To`                              AS `To`,
       `pipedrive`.`aircall_calls_historical`.`User ID`                         AS `User ID`
from `pipedrive`.`aircall_calls_historical`;

