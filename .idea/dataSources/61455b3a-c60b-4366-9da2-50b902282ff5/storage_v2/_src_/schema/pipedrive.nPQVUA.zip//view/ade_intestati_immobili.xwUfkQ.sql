create definer = pipedrive@`%` view ade_intestati_immobili as
select `a`.`id_intestati` AS `id_intestati`,
       `a`.`id_immobili`  AS `id_immobili`,
       `a`.`quota`        AS `quota`,
       `a`.`titolarita`   AS `titolarita`,
       `a`.`created_at`   AS `created_at`,
       `a`.`updated_at`   AS `updated_at`
from `ade_production`.`intestati_immobili` `a`;

