create definer = pipedrive@`%` view date_table as
select distinct `pipedrive`.`marketing_facebook`.`Day` AS `Day`
from `pipedrive`.`marketing_facebook`;

