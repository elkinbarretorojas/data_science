create definer = pipedrive@`%` view ade_indirizzi as
select `ade_production`.`indirizzi`.`id`             AS `id`,
       `ade_production`.`indirizzi`.`id_citta`       AS `id_citta`,
       `ade_production`.`indirizzi`.`indirizzo`      AS `indirizzo`,
       `ade_production`.`indirizzi`.`in_progress_at` AS `in_progress_at`,
       `ade_production`.`indirizzi`.`done_at`        AS `done_at`,
       `ade_production`.`indirizzi`.`error_at`       AS `error_at`
from `ade_production`.`indirizzi`;

