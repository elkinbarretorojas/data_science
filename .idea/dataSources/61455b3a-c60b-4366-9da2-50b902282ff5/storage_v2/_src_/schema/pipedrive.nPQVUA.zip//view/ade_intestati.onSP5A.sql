create definer = pipedrive@`%` view ade_intestati as
select `a`.`id`                               AS `id`,
       `a`.`codfisc`                          AS `codfisc`,
       `a`.`nominativo`                       AS `nominativo`,
       `a`.`email`                            AS `email`,
       `a`.`telefono`                         AS `telefono`,
       `a`.`cellulare`                        AS `cellulare`,
       `a`.`indirizzo`                        AS `indirizzo`,
       `a`.`created_at`                       AS `created_at`,
       `a`.`updated_at`                       AS `updated_at`,
       `a`.`sent`                             AS `sent`,
       `a`.`codice_ade`                       AS `codice_ade`,
       `a`.`status_ricerca_nazionale`         AS `status_ricerca_nazionale`,
       `a`.`ricerca_nazionale_in_progress_at` AS `ricerca_nazionale_in_progress_at`,
       `a`.`ricerca_nazionale_done_at`        AS `ricerca_nazionale_done_at`,
       `a`.`ricerca_nazionale_error_at`       AS `ricerca_nazionale_error_at`
from `ade_production`.`intestati` `a`;

